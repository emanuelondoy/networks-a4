//! Peering: no payment. Each side carries traffic to the other's customers.
use switch_program_sdk::wire::{SettleInput2W, SettleOutputW};

fn settle(input: &SettleInput2W) -> SettleOutputW {
    input.out()
}

// A starter: put your own team codes, world, numbers and words in.
switch_program_sdk::agreement_program! {
    settle: settle,
    world: 1,
    parties: ["ABA", "SLA"],
    links: [("ABA", "SLA", "peer")],
    cap: 0,
    rounds: 1,
    terms: [],
    reads: ["ABA and SLA peer: each carries traffic to the other's customers.", "Nobody pays."],
}
